//
//  RSSViewController.h
//  Tabs
//
//  Created by Dina Li on 10/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Parser.h"
#import "Record.h"

@interface RSSViewController : UITableViewController

@end
