//
//  Tweet.m
//  Tabs
//
//  Created by Dina Li on 9/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Tweet.h"

@implementation Tweet

@synthesize title = _title;
@synthesize subtitle = _subtitle;
@synthesize imageURLString = _imageURLString;
@synthesize summary = _summary;
@synthesize icon = _icon;
@synthesize appURLString = _appURLString;

@end
