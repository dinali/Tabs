//
//  Title.m
//  Tabs
//
//  Created by Dina Li on 10/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Title.h"

@implementation Title
@synthesize title = _title;
@end
