//
//  Record.h
//
//  Created by Dina Li on 9/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Record : NSObject

@property (strong, nonatomic)NSString *descriptionString;
@property (strong, nonatomic)NSString *titleString;
@property(strong, nonatomic)NSString *linkString;

@end
