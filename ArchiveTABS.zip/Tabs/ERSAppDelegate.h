//
//  ERSAppDelegate.h
//  Tabs
//
//  Created by Dina Li on 9/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Tab0ViewController;

@interface ERSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) Tab0ViewController *tab0viewController;
//@property (strong,nonatomic) NSMutableArray *tweetsArray;

@end
