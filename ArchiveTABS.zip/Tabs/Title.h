//
//  Title.h
//  Tabs
//
//  Created by Dina Li on 10/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Title : NSObject
@property(weak, nonatomic) NSString *title;
@end
