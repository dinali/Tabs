//
//  Record.m
//  ParseERSfeed
//
//  Created by Dina Li on 9/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Record.h"

@implementation Record

@synthesize descriptionString = _descriptionString;
@synthesize titleString = _titleString;
@synthesize linkString = _linkString;

@end

